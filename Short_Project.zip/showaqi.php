<?php
session_start();

if (!isset($_SESSION['user'])) {
    die("<h3 style='color:red; text-align:center;'>Access denied. Please log in first.</h3>");
}

$user_email = $_SESSION['user'];

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_POST['cities']) || count($_POST['cities']) !== 10) {
    echo "<h3 style='color:red; text-align:center;'>Access denied or invalid selection. Please go back and select exactly 10 cities.</h3>";
    exit;
}

$selectedCities = $_POST['cities'];

$host = "localhost";
$username = "root";
$password = "";
$dbname = "aqi";

$conn = new mysqli($host, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch favorite color
$bgColor = "#f2f2f2"; // default same as requestaqi.php
$stmtColor = $conn->prepare("SELECT favorite_color FROM userinfo WHERE email = ?");
$stmtColor->bind_param("s", $user_email);
$stmtColor->execute();
$resultColor = $stmtColor->get_result();
if ($rowColor = $resultColor->fetch_assoc()) {
    if (!empty($rowColor['favorite_color'])) {
        $bgColor = $rowColor['favorite_color'];
    }
}
$stmtColor->close();

// Prepare statement for cities
$placeholders = implode(',', array_fill(0, count($selectedCities), '?'));
$sql = "SELECT city, country, aqi FROM info WHERE city IN ($placeholders)";
$stmt = $conn->prepare($sql);

if (!$stmt) {
    die("SQL Error: " . $conn->error);
}

$stmt->bind_param(str_repeat('s', count($selectedCities)), ...$selectedCities);
$stmt->execute();
$result = $stmt->get_result();

$data = [];
while ($row = $result->fetch_assoc()) {
    $data[] = $row;
}

$stmt->close();
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<title>Selected AQI Info</title>
<style>
    body {
        font-family: 'Segoe UI', sans-serif;
        margin: 0;
        padding: 40px;
        background-color: <?php echo htmlspecialchars($bgColor); ?>;
        color: #333;
    }

    /* Top bar */
    .top-bar {
        position: fixed;
        top: 10px;
        right: 20px;
        text-align: right;
        font-size: 14px;
        font-family: Arial, sans-serif;
        color: #222;
        z-index: 9999;
    }

    .top-bar div {
        margin-bottom: 4px;
    }

    .signout-btn {
        color: #0077cc;
        text-decoration: none;
        font-weight: bold;
    }

    .signout-btn:hover {
        text-decoration: underline;
    }

    h2 {
        text-align: center;
        color: #222;
    }

    .form-container {
        max-width: 700px;
        margin: auto;
        background-color: white;
        padding: 30px;
        border-radius: 12px;
        box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
    }

    table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 20px;
    }

    th, td {
        border: 1px solid #ccc;
        padding: 12px 15px;
        text-align: left;
    }

    th {
        background-color: #f4f4f4;
        font-weight: 600;
    }

    tr:nth-child(even) {
        background-color: #f9f9f9;
    }

    .back-button {
        display: block;
        width: fit-content;
        margin: 25px auto 0;
        padding: 12px 30px;
        font-size: 16px;
        background-color: #0077cc;
        color: white;
        text-decoration: none;
        border-radius: 8px;
        text-align: center;
        transition: background 0.3s ease;
    }

    .back-button:hover {
        background-color: #005fa3;
    }
</style>
</head>
<body>

<div class="top-bar">
    <div>
        <strong><a href="userinfo.php" style="color: inherit; text-decoration: none;">
            Username:
        </a></strong>
        <a href="userinfo.php" style="ccolor:#0077cc; text-decoration: none;">
            <?php echo htmlspecialchars($user_email); ?>
        </a>
    </div>
    <div><a href="logout.php" class="signout-btn">Sign Out</a></div>
</div>


<div class="form-container">
    <h2>AQI Information for Selected Cities</h2>

    <?php if (count($data) > 0): ?>
        <table>
            <thead>
                <tr>
                    <th>City</th>
                    <th>Country</th>
                    <th>AQI</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($data as $row): ?>
                <tr>
                    <td><?php echo htmlspecialchars($row['city']); ?></td>
                    <td><?php echo htmlspecialchars($row['country']); ?></td>
                    <td><?php echo htmlspecialchars($row['aqi']); ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php else: ?>
        <p style="text-align:center; font-weight: bold;">No data found for the selected cities.</p>
    <?php endif; ?>

    <a href="requestaqi.php" class="back-button">Back to Selection</a>
</div>

</body>
</html>
