<?php
session_start();

$servername = "localhost";
$username = "root"; // your DB username
$password = "";     // your DB password
$dbname = "aqi";

$favorite_color = '#667eea'; // default fallback color
$insert_error = "";
$show_success = false;

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['final_submit'])) {
        // This block runs when Confirm button is clicked
        if (!isset($_SESSION['form_data'])) {
            $insert_error = "Session expired or no data found.";
        } else {
            $data = $_SESSION['form_data'];
            $first_name = $data['fname'] ?? '';
            $last_name = $data['lname'] ?? '';
            $email = $data['email'] ?? '';
            $password_plain = $data['pwd'] ?? '';
            $dob = $data['birthday'] ?? '';
            $country = $data['countryInput'] ?? '';
            $gender = $data['Gender'] ?? '';
            $favorite_color = $data['favcolor'] ?? $favorite_color;

            $conn = new mysqli($servername, $username, $password, $dbname);
            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }

            // Check if email exists
            $email_check_stmt = $conn->prepare("SELECT COUNT(*) FROM userinfo WHERE email = ?");
            $email_check_stmt->bind_param("s", $email);
            $email_check_stmt->execute();
            $email_check_stmt->bind_result($count);
            $email_check_stmt->fetch();
            $email_check_stmt->close();

            if ($count > 0) {
                $insert_error = "Email already exists. Please use another email.";
            } else {
                // Insert raw password (no encryption)
                $stmt = $conn->prepare("INSERT INTO userinfo (first_name, last_name, email, password, dob, country, gender, favorite_color) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
                if (!$stmt) {
                    $insert_error = "Prepare failed: " . $conn->error;
                } else {
                    $stmt->bind_param("ssssssss", $first_name, $last_name, $email, $password_plain, $dob, $country, $gender, $favorite_color);
                    if ($stmt->execute()) {
                        unset($_SESSION['form_data']);
                        $show_success = true;
                    } else {
                        $insert_error = "Insert failed: " . $stmt->error;
                    }
                    $stmt->close();
                }
            }
            $conn->close();
        }
    } else {
        // First POST - form submitted initially, store data in session and show preview
        $_SESSION['form_data'] = $_POST;

        $first_name = htmlspecialchars($_POST['fname'] ?? '');
        $last_name = htmlspecialchars($_POST['lname'] ?? '');
        $email = htmlspecialchars($_POST['email'] ?? '');
        $password = $_POST['pwd'] ?? '';
        $dob = htmlspecialchars($_POST['birthday'] ?? '');
        $country = htmlspecialchars($_POST['countryInput'] ?? '');
        $gender = htmlspecialchars($_POST['Gender'] ?? '');
        $favorite_color = htmlspecialchars($_POST['favcolor'] ?? $favorite_color);

        $masked_password = str_repeat('•', strlen($password));
    }
} else {
    $first_name = $last_name = $email = $password = $dob = $country = $gender = "";
    $masked_password = "";
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <title>Form Submission</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 50px;
            color: #fff;
            transition: background 0.5s ease;
            background: <?php echo htmlspecialchars($favorite_color); ?>;
        }

        .container {
            background: #ffffff;
            color: #333;
            max-width: 600px;
            margin: auto;
            padding: 30px 40px;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
            transition: all 0.3s ease-in-out;
            text-align: center;
        }

        .container:hover {
            transform: scale(1.01);
        }

        h2 {
            text-align: center;
            font-size: 28px;
            margin-bottom: 25px;
            color: #764ba2;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            font-size: 16px;
            margin-bottom: 20px;
        }

        td {
            text-align: left;
            padding: 12px 15px;
            border-bottom: 1px solid #ddd;
        }

        tr:hover {
            background-color: #f9f9f9;
        }

        .color-box {
            display: inline-block;
            width: 20px;
            height: 20px;
            vertical-align: middle;
            border-radius: 4px;
            margin-right: 8px;
            box-shadow: 0 0 5px rgba(0,0,0,0.2);
            border: 1px solid #ccc;
        }

        button.toggle-btn, button.action-btn {
            padding: 6px 16px;
            font-size: 15px;
            cursor: pointer;
            border: none;
            background-color: #667eea;
            color: white;
            border-radius: 5px;
            transition: background-color 0.3s ease;
            margin: 0 8px;
        }

        button.toggle-btn:hover, button.action-btn:hover {
            background-color: #5563c1;
        }

        .success-msg {
            padding: 20px;
            background: #d4edda;
            color: #155724;
            border-radius: 8px;
            margin-bottom: 20px;
            font-weight: bold;
        }

        .error-msg {
            padding: 15px;
            background: #f8d7da;
            color: #721c24;
            border-radius: 8px;
            margin-bottom: 20px;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>🌟 Submitted Information 🌟</h2>

        <?php if ($show_success): ?>
            <div class="success-msg">
                ✅ Data saved successfully! Redirecting to homepage in 3 seconds...
            </div>
            <script>
                setTimeout(() => {
                    window.location.href = "index.html";
                }, 3000);
            </script>
        <?php else: ?>

            <?php if (!empty($insert_error)) : ?>
                <div class="error-msg"><?php echo $insert_error; ?></div>
            <?php endif; ?>

            <?php if (!empty($first_name)) : ?>
                <table>
                    <tr>
                        <td><strong>First Name</strong></td>
                        <td><?php echo $first_name; ?></td>
                    </tr>
                    <tr>
                        <td><strong>Last Name</strong></td>
                        <td><?php echo $last_name; ?></td>
                    </tr>
                    <tr>
                        <td><strong>Email</strong></td>
                        <td><?php echo $email; ?></td>
                    </tr>
                    <tr>
                        <td><strong>Password</strong></td>
                        <td>
                            <span id="passwordMasked"><?php echo str_repeat('•', strlen($password)); ?></span>
                            <span id="passwordText" style="display:none;"><?php echo htmlspecialchars($password); ?></span>
                            <button type="button" class="toggle-btn" onclick="togglePassword(event)">Show</button>
                        </td>
                    </tr>
                    <tr>
                        <td><strong>Date of Birth</strong></td>
                        <td><?php echo $dob; ?></td>
                    </tr>
                    <tr>
                        <td><strong>Country</strong></td>
                        <td><?php echo $country; ?></td>
                    </tr>
                    <tr>
                        <td><strong>Gender</strong></td>
                        <td><?php echo $gender; ?></td>
                    </tr>
                    <tr>
                        <td><strong>Favorite Color</strong></td>
                        <td><span class="color-box" style="background: <?php echo htmlspecialchars($favorite_color); ?>;"></span> <?php echo htmlspecialchars($favorite_color); ?></td>
                    </tr>
                </table>

                <form method="post" style="margin-top: 20px;">
                    <button type="button" class="action-btn" onclick="goBack()">Back</button>
                    <button type="submit" name="final_submit" class="action-btn">Confirm</button>
                </form>
            <?php else: ?>
                <p>No data submitted.</p>
            <?php endif; ?>

        <?php endif; ?>
    </div>

    <script>
        function togglePassword(event) {
            const btn = event.target;
            const passwordMasked = document.getElementById('passwordMasked');
            const passwordText = document.getElementById('passwordText');

            if (passwordMasked.style.display === 'none') {
                passwordMasked.style.display = 'inline';
                passwordText.style.display = 'none';
                btn.textContent = 'Show';
            } else {
                passwordMasked.style.display = 'none';
                passwordText.style.display = 'inline';
                btn.textContent = 'Hide';
            }
        }

        function goBack() {
            window.location.href = 'index.html';
        }
    </script>
</body>
</html>
