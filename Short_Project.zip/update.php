<?php
session_start();
if (!isset($_SESSION['user'])) {
    die("<h3 style='color:red; text-align:center;'>Access denied. Please log in first.</h3>");
}

$email = $_SESSION['user'];

$host = "localhost";
$dbUsername = "root";
$dbPassword = "";
$dbname = "aqi";

$conn = new mysqli($host, $dbUsername, $dbPassword, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch current values
$stmt = $conn->prepare("SELECT favorite_color, password FROM userinfo WHERE email = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();
$currentColor = $user['favorite_color'];
$currentPassword = $user['password'];
$stmt->close();

$bgColor = $currentColor ?: '#f9f9f9';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $newColor = $_POST['favorite_color'];
    $oldPassword = $_POST['old_password'];
    $newPassword = $_POST['new_password'];
    $confirmPassword = $_POST['confirm_password'];

    if ($oldPassword !== $currentPassword) {
        echo "<script>alert('Old password is incorrect.');</script>";
    } elseif ($newPassword !== $confirmPassword) {
        echo "<script>alert('New passwords do not match.');</script>";
    } else {
        $stmt = $conn->prepare("UPDATE userinfo SET favorite_color = ?, password = ? WHERE email = ?");
        $stmt->bind_param("sss", $newColor, $newPassword, $email);

        if ($stmt->execute()) {
            echo "<script>alert('Information updated successfully! Please log in again.'); window.location.href='logout.php';</script>";
            exit();
        } else {
            echo "<p style='color:red; text-align:center;'>Update failed. Please try again.</p>";
        }
        $stmt->close();
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Update Information</title>
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            background: <?php echo htmlspecialchars($bgColor); ?>;
            padding: 40px;
        }
        .container {
            max-width: 500px;
            margin: auto;
            background: white;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.1);
        }
        h2 {
            text-align: center;
            color: #333;
        }
        label {
            display: block;
            margin: 15px 0 5px;
            font-weight: bold;
        }
        input[type="text"], input[type="password"], input[type="color"] {
            width: 100%;
            padding: 10px;
            border-radius: 8px;
            border: 1px solid #ccc;
        }
        button {
            margin-top: 20px;
            width: 100%;
            padding: 12px;
            background: #28a745;
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 16px;
        }
        .back-link {
            display: block;
            text-align: center;
            margin-top: 20px;
            color: #0077cc;
            text-decoration: none;
            font-weight: bold;
        }
        .back-link:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Update Information</h2>
    <form method="post">
        <label for="favorite_color">Favorite Color:</label>
        <input type="color" id="favorite_color" name="favorite_color" value="<?php echo htmlspecialchars($currentColor); ?>" required>

        <label for="old_password">Old Password:</label>
        <input type="password" id="old_password" name="old_password" required>

        <label for="new_password">New Password:</label>
        <input type="password" id="new_password" name="new_password" required>

        <label for="confirm_password">Confirm New Password:</label>
        <input type="password" id="confirm_password" name="confirm_password" required>

        <button type="submit">Update</button>
    </form>
    <a href="userinfo.php" class="back-link">Back to User Info</a>
</div>

</body>
</html>
