<?php
session_start();

if (!isset($_SESSION['user'])) {
    die("<h3 style='color:red; text-align:center;'>Access denied. Please log in first.</h3>");
}
$email = $_SESSION['user'];

// Database connection
$host = "localhost";
$dbUsername = "root";
$dbPassword = "";
$dbname = "aqi";

$conn = new mysqli($host, $dbUsername, $dbPassword, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch user's background color
$stmt = $conn->prepare("SELECT favorite_color FROM userinfo WHERE email = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();

$bgColor = "#f2f2f2"; // Default background
$row = $result->fetch_assoc();
if ($row && !empty($row['favorite_color'])) {
    $bgColor = $row['favorite_color'];
}
$stmt->close();

// Fetch cities
$sql = "SELECT DISTINCT city FROM info ORDER BY city ASC";
$result = $conn->query($sql);

$cities = [];
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $cities[] = $row['city'];
    }
}
$conn->close();

// Server-side validation if needed
$error = "";
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    if (!isset($_POST['cities']) || count($_POST['cities']) !== 10) {
        $error = "Please select exactly 10 cities.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Select 10 Cities</title>
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            margin: 0;
            padding: 40px;
            background-color: <?php echo htmlspecialchars($bgColor); ?>;
            color: #333;
        }

        .top-bar {
            position: fixed;
            top: 10px;
            right: 20px;
            text-align: right;
            font-size: 14px;
            font-family: Arial, sans-serif;
            color: #222;
        }

        .top-bar div {
            margin-bottom: 4px;
        }

        .signout-btn {
            color: #0077cc;
            text-decoration: none;
            font-weight: bold;
        }

        .signout-btn:hover {
            text-decoration: underline;
        }

        h2 {
            text-align: center;
            color: #222;
        }

        .form-container {
            max-width: 700px;
            margin: auto;
            background-color: white;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        td {
            padding: 10px;
            vertical-align: top;
        }

        label {
            display: block;
            margin-bottom: 8px;
            font-size: 16px;
        }

        .submit-btn {
            display: block;
            margin: 20px auto 0;
            padding: 12px 30px;
            font-size: 16px;
            background-color: #0077cc;
            color: white;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            transition: background 0.3s ease;
        }

        .submit-btn:hover {
            background-color: #005fa3;
        }

        .error {
            color: red;
            font-weight: bold;
            text-align: center;
        }
    </style>
    <script>
        function validateForm() {
            const checkboxes = document.querySelectorAll('input[name="cities[]"]:checked');
            if (checkboxes.length !== 10) {
                alert("Please select exactly 10 cities.");
                return false;
            }
            return true;
        }
    </script>
</head>
<body>

<div class="top-bar">
    <div><strong>Username:</strong> <a href="userinfo.php" style="color:#0077cc; text-decoration:none;"><?php echo htmlspecialchars($email); ?></a></div>
    <div><a href="logout.php" class="signout-btn">Sign Out</a></div>
</div>


<div class="form-container">
    <h2>Select Exactly 10 Cities</h2>

    <?php if ($error): ?>
        <p class="error"><?php echo htmlspecialchars($error); ?></p>
    <?php endif; ?>

    <form method="POST" action="showaqi.php?email=<?php echo urlencode($email); ?>" onsubmit="return validateForm()">
        <table>
            <?php
            $cols = 2;
            $rows = ceil(count($cities) / $cols);
            for ($i = 0; $i < $rows; $i++) {
                echo "<tr>";
                for ($j = 0; $j < $cols; $j++) {
                    $index = $i + $j * $rows;
                    echo "<td>";
                    if (isset($cities[$index])) {
                        $city = htmlspecialchars($cities[$index]);
                        echo "<label><input type='checkbox' name='cities[]' value='$city'> $city</label>";
                    }
                    echo "</td>";
                }
                echo "</tr>";
            }
            ?>
        </table>
        <button type="submit" class="submit-btn">Submit</button>
    </form>
</div>

</body>
</html>
